<?php 


$to = "paul.cevallos@hotmail.com";
$subject = "My subject";
$txt = "Hello world! todo ok ";
$headers = "From: herrera.byron@gmail.com" . "\r\n" .
"CC: byron.herrera@quito.gob.ec";

mail($to,$subject,$txt,$headers);

?>